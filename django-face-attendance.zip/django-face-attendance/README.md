# Django AI Face Recognition Attendance System (PyTorch + FaceNet VGGFace2)

## 📌 Project Overview

An advanced, premium web-based **AI Face Recognition Attendance System** built using **Django**, **PyTorch (InceptionResnetV1/FaceNet)**, and **OpenCV (LBPH Fallback)**. 

This system provides a full web interface for faculty authentication, student record directory management, real-time webcam face check-ins, automated Excel reporting, and a custom glassmorphic administration panel. It features a thread-safe, asynchronous background face encoding pipeline with a live step-by-step progress modal in the frontend.

---

## 💎 Features & Customizations

### 🖥️ 1. Modern Glassmorphic Dashboard
- **Analytics Cards**: Interactive indicators for average attendance rates, total sessions, handling subjects, and checked-in counts.
- **Faculty Profiles**: Protected views dynamically displaying profile data (Full Name, Department, Email) via Django Session Authentication.

### 👥 2. Student Directory & CRUD Panel
- **Profile Management**: Register new students, upload face photos, edit details, and delete profiles.
- **Asynchronous Deep Learning Encoding**: Profile saving triggers a background thread that extracts 512-D FaceNet face vectors and retrains the LBPH face classifier.
- **Step-by-Step Progress Wizard**: A full-screen overlay modal in the frontend displays a circular progress percentage ring and a checklist showing completion indicators for each background phase in real time:
  1. *Database Record Setup* (15%)
  2. *Photo File Analysis* (30%)
  3. *FaceNet Embedding Calculation* (60%)
  4. *LBPH Local Model Training* (85%)
  5. *Profile Active* (100% / Success)
  - If no face is detected, it transitions to a **Failed state** showing the warning details and options to choose another file.

### 🎥 3. Real-Time Webcam Scanner
- **MJPEG Streaming**: Serves annotated webcam frames directly to browser templates.
- **Dual Verification Engine**: Cosine distance mapping (< 0.4) on 512-D FaceNet vectors, falling back to local LBPH class predictions.
- **Multi-Frame Voting (4/5)**: Eliminates false positives by verifying face match consistency across consecutive frames before check-in.
- **Cooldown Lock**: A 60-second database check-in lock prevents duplicated logs.

### 🔒 4. Redesigned Site Administration (Django Admin)
- **Glassmorphic Overrides**: Transparent `.module` frames with `backdrop-filter: blur(10px)` and glowing borders matching the parent theme.
- **App Caption Gradients**: Deep dark purple-to-blue gradient app headings replacing the default flat admin headers.
- **Pill Buttons**: Glassmorphic action pill elements for `+ Add` and `Change` links.
- **Dynamic Icons**: JavaScript scans model rows to inject appropriate FontAwesome icons (`Students` -> graduate, `Attendance logs` -> clock, etc.).
- **Timeline Feed**: Modern Activity log list styling.
- **In-List Status Polling**: Admin changelist columns feature live progress bars and step labels showing face status processing.

---

## ⚙️ Technologies Used

* **Web Framework**: Django 5.0.6
* **Deep Learning Engine**: PyTorch, `facenet-pytorch` (InceptionResnetV1 pre-trained on VGGFace2)
* **Computer Vision**: OpenCV (`opencv-contrib-python` for Haar Cascades & LBPH face classifiers)
* **Data Processing**: Pandas, OpenPyXL (Excel export engine)
* **Database**: SQLite (SQL query serialization with connection closures)
* **Design Engine**: HSL Vanilla CSS, FontAwesome 6, SVG circular progress rings

---

## 📂 Project Directory Structure

```text
django-face-attendance/
├── manage.py
├── requirements.txt
├── README.md
├── db.sqlite3
├── Models/                     # Deep learning models directory
│   ├── facenet_model/          # FaceNet weights
│   └── lbph_model/             # Trained LBPH .yml classifiers
├── media/
│   └── students/               # Profile face photos uploads
├── face_attendance_project/    # App settings & routing
└── attendance/                 # Core Attendance module
    ├── admin.py                # Admin customization helpers
    ├── models.py               # Student background thread save hooks
    ├── views.py                # Video feeds, AJAX pollers, & auth views
    ├── urls.py                 # View routing
    ├── templates/              # HTML layout templates
    │   ├── admin/
    │   │   └── base_site.html  # Custom admin overrides stylesheet/js
    │   └── attendance/         # Main frontend templates
    │       ├── base.html
    │       ├── dashboard.html
    │       ├── login.html
    │       ├── register.html
    │       └── manage_students.html
    └── static/
        └── attendance/
            └── style.css       # Core stylesheet definitions
```

---

## 🚀 Setup & Execution Guide

### 1. Requirements Installation
Unlike legacy implementations, this system relies on PyTorch and standard OpenCV contributions. You do **not** need to install `dlib`, `cmake`, or Visual Studio build compilers:

```bash
pip install -r requirements.txt
```

### 2. Apply Database Migrations
Build database tables and columns:

```bash
python manage.py makemigrations
python manage.py migrate
```

### 3. Create Administration Account
Create a faculty account to access both Django Admin and the frontend dashboard:

```bash
python manage.py createsuperuser
```

### 4. Run Development Server
Start the Django development server:

```bash
python manage.py runserver
```
Open `http://127.0.0.1:8000/` in your browser.

---

## 📊 Verification Utility
To migrate legacy databases or run face calculations manually, execute the recomputation script:
```bash
python recompute_encodings.py
```
This forces FaceNet embed extraction and trains the local LBPH fallback classifier file.

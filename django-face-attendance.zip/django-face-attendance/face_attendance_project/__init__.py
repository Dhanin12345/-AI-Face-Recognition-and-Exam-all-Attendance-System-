# Django project initialization file

# Django app initialization file
